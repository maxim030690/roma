<?php

// no direct access
defined('UNLIMITED_ADDONS_INC') or die;


class UniteCreatorGridBuilderProvider extends UniteCreatorGridBuilder{
	
	
	/**
	 * constructor
	 */
	public function __construct(){
		
		parent::__construct();
		
	}
	
	
}