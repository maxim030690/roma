<?php

defined('UNLIMITED_ADDONS_INC') or die('Restricted access');

class GlobalsProviderUC{
	
	const VIEW_ADDONS_VC = "addons_vc";
	const ADDONS_TYPE_VC = "vc";
	const LAYOUTS_POST_TYPE = "uc_layout";
	
}